#!/usr/bin/python
# Copyright: (c) 2023, Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

# This is a stub to get the docs working, the implementation is an action plugin
